puppet-sealion
===========i

puppetised version of  the installer for https://sealion.com/
